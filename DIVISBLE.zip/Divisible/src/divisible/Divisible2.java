//EMMANUEL ARZATE HERNANDEZ POO 2023B

package divisible;

import java.util.Scanner;

public class Divisible2 {

    public static void Ejercicio_Divisible_2() {
        int n, d;
        Scanner entrada = new Scanner(System.in);
        System.out.print("Introduzca primer digito ");
        n = entrada.nextInt();
        System.out.print("Introduzca segundo digito ");
        d = entrada.nextInt();
        
        if (n%d == 0) {
            System.out.println(n + " es divisible entre " + d);
        } else {
            System.out.println(n + " no es divisible entre " + d);
        }
    }
    public static void main(String args[]){
        Divisible2 divisible= new Divisible2();
        divisible.Ejercicio_Divisible_2();
    }
}
