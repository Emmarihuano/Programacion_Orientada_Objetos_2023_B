//EMMANUEL ARZATE HERNANDEZ POO 2023B

package divisible;

import java.util.Scanner;

public class Divisible {

    public static void Ejemplo_de_clase() {
        int n, d;

        Scanner entrada = new Scanner(System.in);
        System.out.println("Introduzca dos digitos:");
        n = entrada.nextInt();
        d = entrada.nextInt();
        if (n%d == 0) {
            System.out.println(n + " es divisible por " + d);
        }
    }
    public static void main(String args[]){
        Divisible divisible= new Divisible();
        divisible.Ejemplo_de_clase();
    }

}
