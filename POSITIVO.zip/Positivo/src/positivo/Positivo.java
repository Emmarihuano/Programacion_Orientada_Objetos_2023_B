//EMMANUEL ARZATE HERNANDEZ POO 2023B

package positivo;
import java.util.Scanner;

public class Positivo {

    public void po_si_ti_vo(){
        
        float numero;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Introduzca un numero real");
        numero = entrada.nextFloat();
        if (numero > 0) {
            System.out.println(numero + " es mayor que cero");
        }
}
    public static void main(String[] args){
        Positivo numero = new Positivo();
        numero.po_si_ti_vo();

    }

}
