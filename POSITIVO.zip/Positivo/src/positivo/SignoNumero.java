//EMMANUEL ARZATE HERNANDEZ POO 2023B

package positivo;

import java.util.Scanner;

public class SignoNumero {
    
    
    public void Signo_Numero(){
       
       float numero;
        Scanner entrada = new Scanner(System.in);
        System.out.println("Introduzca un numero real");
        numero = entrada.nextFloat();

        if (numero > 0) {
            System.out.println(numero + " es mayor que cero");
        }
        if (numero < 0) {
            System.out.println(numero + " es menor que cero");
        }
        if (numero == 0) {
            System.out.println(numero + " es igual que cero");
        }
    
}

    public static void main(String args[]) {

      SignoNumero nuevo = new SignoNumero();
      nuevo.Signo_Numero();
    }

}
